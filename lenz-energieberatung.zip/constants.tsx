
import React from 'react';
import { 
  FileText, 
  Map, 
  Thermometer, 
  Settings, 
  Target
} from 'lucide-react';
import { Service, FAQItem, ProcessStep } from './types';

export const CONTACT_INFO = {
  name: "Lenz Energieberatung",
  owner: "Markus Lenz",
  address: "Kirchstr. 55, 40227 Düsseldorf",
  phone: "01573 6533337",
  email: "info@lenzenergieberatung.de",
  qualifications: ["Schornsteinfegermeister", "Energieeffizienz-Experte"]
};

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  author: string;
  image: string;
  category: string;
}

export interface ServiceDetail extends Service {
  longDescription: string;
  benefits: string[];
  documents: string[];
  pricing: string;
  faqs: FAQItem[];
  seoTitle: string;
  seoMeta: string;
}

export const BLOG_POSTS: BlogPost[] = [
  {
    id: "foerderung-2024",
    title: "Neue Förderrichtlinien 2024: Das müssen Eigentümer in Düsseldorf wissen",
    excerpt: "Die BEG-Förderung hat sich zum Jahreswechsel massiv geändert. Wir fassen die wichtigsten Punkte für Ihre Sanierung zusammen.",
    content: "<p>Hier folgt der detaillierte Inhalt zum Thema Förderrichtlinien 2024...</p>",
    date: "15.02.2024",
    author: "Markus Lenz",
    category: "Förderung",
    image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "waermepumpe-altbau",
    title: "Wärmepumpe im Altbau: Funktioniert das wirklich?",
    excerpt: "Viele Mythen ranken sich um die Wärmepumpe in bestehenden Gebäuden. Ein technischer Check aus der Praxis.",
    content: "<p>Hier folgt der detaillierte Inhalt zum Thema Wärmepumpe im Altbau...</p>",
    date: "02.02.2024",
    author: "Markus Lenz",
    category: "Technik",
    image: "https://images.unsplash.com/photo-1581094288338-2314dddb7e8c?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "energieausweis-check",
    title: "Energieausweis-Check: Wann ist er wirklich Pflicht?",
    excerpt: "Bußgelder bis zu 15.000 Euro drohen bei fehlendem Ausweis. Wir erklären die rechtliche Lage für Vermieter.",
    content: "<p>Hier folgt der detaillierte Inhalt zum Thema Energieausweis-Check...</p>",
    date: "20.01.2024",
    author: "Markus Lenz",
    category: "Recht",
    image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "hydraulischer-abgleich-vorteile",
    title: "Der unterschätzte Hebel: Warum der hydraulische Abgleich 15% Heizkosten spart",
    excerpt: "Kleine Maßnahme, große Wirkung. Wie eine perfekt eingestellte Heizung Ihren Wohnkomfort steigert.",
    content: "<p>Hier folgt der detaillierte Inhalt zum Thema hydraulischer Abgleich...</p>",
    date: "10.01.2024",
    author: "Markus Lenz",
    category: "Effizienz",
    image: "https://images.unsplash.com/photo-1517089152318-42ec560349c0?auto=format&fit=crop&q=80&w=800"
  },
  {
    id: "sanierungsfahrplan-bonus",
    title: "5% Extra-Förderung: Der iSFP-Sanierungsfahrplan lohnt sich doppelt",
    excerpt: "Mit einem Sanierungsfahrplan sichern Sie sich nicht nur eine Strategie, sondern auch mehr Geld vom Staat.",
    content: "<p>Hier folgt der detaillierte Inhalt zum Thema iSFP-Bonus...</p>",
    date: "05.01.2024",
    author: "Markus Lenz",
    category: "Förderung",
    image: "https://images.unsplash.com/photo-1460472178825-e5240623abe5?auto=format&fit=crop&q=80&w=800"
  }
];

export const LEGAL_CONTENT = {
  impressum: {
    title: "Impressum",
    content: `
      <h2 class="text-xl font-bold mb-4">Angaben gemäß § 5 TMG</h2>
      <p class="mb-4">
        Lenz Energieberatung<br>
        Markus Lenz<br>
        Kirchstr. 55<br>
        40227 Düsseldorf
      </p>

      <h2 class="text-xl font-bold mb-4">Kontakt</h2>
      <p class="mb-4">
        Telefon: 01573 6533337<br>
        E-Mail: info@lenzenergieberatung.de
      </p>

      <h2 class="text-xl font-bold mb-4">Berufsbezeichnung und berufsrechtliche Regelungen</h2>
      <p class="mb-4">
        Berufsbezeichnung: Schornsteinfegermeister (verliehen in der Bundesrepublik Deutschland)<br>
        Zuständige Kammer: Handwerkskammer Düsseldorf
      </p>

      <h2 class="text-xl font-bold mb-4">EU-Streitschlichtung</h2>
      <p class="mb-4">
        Die Europäische Kommission stellt eine Plattform zur Online-Streitbeilegung (OS) bereit: <a href="https://ec.europa.eu/consumers/odr/" target="_blank" class="text-emerald-600 underline">https://ec.europa.eu/consumers/odr/</a>.<br>
        Unsere E-Mail-Adresse finden Sie oben im Impressum.
      </p>

      <h2 class="text-xl font-bold mb-4">Verbraucherstreitbeilegung/Universalschlichtungsstelle</h2>
      <p class="mb-4">
        Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle teilzunehmen.
      </p>
    `
  },
  datenschutz: {
    title: "Datenschutzerklärung",
    content: `
      <h2 class="text-xl font-bold mb-4">1. Datenschutz auf einen Blick</h2>
      <p class="mb-4">Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen Daten passiert, wenn Sie diese Website besuchen.</p>

      <h2 class="text-xl font-bold mb-4">2. Datenerfassung auf dieser Website</h2>
      <h3 class="font-bold mb-2">Kontaktformular</h3>
      <p class="mb-4">Wenn Sie uns per Kontaktformular Anfragen zukommen lassen, werden Ihre Angaben aus dem Anfrageformular inklusive der von Ihnen dort angegebenen Kontaktdaten zwecks Bearbeitung der Anfrage und für den Fall von Anschlussfragen bei uns gespeichert. Diese Daten geben wir nicht ohne Ihre Einwilligung weiter.</p>

      <h3 class="font-bold mb-2">Server-Log-Dateien</h3>
      <p class="mb-4">Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, die Ihr Browser automatisch an uns übermittelt. Dies sind: Browsertyp, Betriebssystem, Referrer URL, Hostname des zugreifenden Rechners, Uhrzeit der Serveranfrage und IP-Adresse.</p>

      <h2 class="text-xl font-bold mb-4">3. Ihre Rechte</h2>
      <p class="mb-4">Sie haben jederzeit das Recht, unentgeltlich Auskunft über Herkunft, Empfänger und Zweck Ihrer gespeicherten personenbezogenen Daten zu erhalten. Sie haben außerdem ein Recht, die Berichtigung oder Löschung dieser Daten zu verlangen.</p>
    `
  },
  agb: {
    title: "Allgemeine Geschäftsbedingungen",
    content: `
      <h2 class="text-xl font-bold mb-4">1. Geltungsbereich</h2>
      <p class="mb-4">Diese Geschäftsbedingungen gelten für alle Verträge zwischen Lenz Energieberatung und ihren Kunden über Beratungsleistungen, Gutachten und die Erstellung von Energieausweisen.</p>

      <h2 class="text-xl font-bold mb-4">2. Vertragsschluss</h2>
      <p class="mb-4">Ein Vertrag kommt durch die schriftliche oder mündliche Beauftragung durch den Kunden und die Annahme durch Lenz Energieberatung zustande.</p>

      <h2 class="text-xl font-bold mb-4">3. Leistungen</h2>
      <p class="mb-4">Der Umfang der Leistungen ergibt sich aus dem jeweiligen Angebot. Wir schulden eine fachgerechte Beratung nach dem aktuellen Stand der Technik (GEG, DIN-Normen).</p>

      <h2 class="text-xl font-bold mb-4">4. Mitwirkungspflichten des Kunden</h2>
      <p class="mb-4">Der Kunde ist verpflichtet, alle für die Erbringung der Leistung erforderlichen Unterlagen (Grundrisse, Heizkostenabrechnungen etc.) rechtzeitig und vollständig zur Verfügung zu stellen.</p>

      <h2 class="text-xl font-bold mb-4">5. Vergütung</h2>
      <p class="mb-4">Die Vergütung richtet sich nach dem vereinbarten Honorar. Alle Preise verstehen sich inklusive der gesetzlichen Mehrwertsteuer, sofern nicht anders angegeben.</p>
    `
  }
};

export const SERVICES: ServiceDetail[] = [
  {
    id: "energieausweis",
    title: "Energieausweise",
    description: "Bedarfs- oder Verbrauchsausweise für Wohngebäude in Düsseldorf.",
    longDescription: "Ein Energieausweis ist nicht nur gesetzliche Pflicht bei Verkauf oder Vermietung, sondern auch ein wichtiges Dokument zur Bewertung der energetischen Qualität Ihres Gebäudes. Als Schornsteinfegermeister begutachte ich Ihre Immobilie vor Ort und erstelle rechtssichere Ausweise nach dem aktuellen Gebäudeenergiegesetz (GEG).",
    icon: <FileText className="w-8 h-8 text-emerald-600" />,
    details: ["Rechtssicher nach GEG", "Schnelle Erstellung", "Vor-Ort-Begehung inkl."],
    benefits: [
      "Rechtssicherheit bei Immobilienverkauf oder Vermietung",
      "Transparente Darstellung der Energiekosten",
      "Konkrete Modernisierungsempfehlungen inklusive",
      "Erstellt durch einen zertifizierten Experten vor Ort"
    ],
    documents: [
      "Baujahr des Gebäudes & der Heizung",
      "Letzte 3 Abrechnungen (bei Verbrauchsausweis)",
      "Grundrisse & Schnitte (bei Bedarfsausweis)",
      "Datenblatt der Heizungsanlage"
    ],
    pricing: "Ab 200,- € (Verbrauchsausweis) bzw. 450,- € (Bedarfsausweis) inkl. MwSt.",
    seoTitle: "Energieausweis Düsseldorf | Rechtssicher & Schnell | Lenz",
    seoMeta: "Energieausweis in Düsseldorf benötigt? Markus Lenz erstellt Bedarfs- & Verbrauchsausweise rechtssicher nach GEG. Jetzt Termin anfragen!",
    faqs: [
      { question: "Wann ist ein Energieausweis in Düsseldorf Pflicht?", answer: "Er ist zwingend erforderlich, sobald Sie eine Immobilie verkaufen, neu vermieten oder verpachten wollen. Auch bei umfangreichen Sanierungen kann ein neuer Ausweis nötig sein." },
      { question: "Verbrauchs- oder Bedarfsausweis?", answer: "Das hängt vom Baujahr und der Anzahl der Wohnungen ab. Gebäude mit weniger als 5 Wohnungen und Bauantrag vor 1977 benötigen meist den Bedarfsausweis, sofern sie nicht die Wärmeschutzverordnung von 1977 erfüllen." },
      { question: "Wie lange ist der Ausweis gültig?", answer: "Ein Energieausweis hat eine Gültigkeitsdauer von 10 Jahren ab Ausstellungsdatum." },
      { question: "Gibt es Bußgelder bei Fehlen?", answer: "Ja, wer bei Verkauf oder Vermietung keinen gültigen Ausweis vorlegt, riskiert Bußgelder von bis zu 15.000 Euro." },
      { question: "Müssen Sie für den Ausweis ins Haus kommen?", answer: "Ja, eine Vor-Ort-Begehung oder eine detaillierte Foto-Dokumentation ist gesetzlich vorgeschrieben, um die Qualität der Daten zu gewährleisten." },
      { question: "Was ist der Unterschied zwischen den Ausweisarten?", answer: "Der Verbrauchsausweis basiert auf den realen Heizkosten der letzten 3 Jahre. Der Bedarfsausweis berechnet den theoretischen Energiebedarf basierend auf der Bausubstanz und Anlagentechnik." }
    ]
  },
  {
    id: "isfp",
    title: "iSFP Sanierungsfahrplan",
    description: "Individueller Sanierungsfahrplan für maximale Förderquoten.",
    longDescription: "Der Individuelle Sanierungsfahrplan (iSFP) ist das zentrale Werkzeug für eine schrittweise oder ganzheitliche energetische Sanierung. Er bietet Ihnen eine langfristige Strategie und sichert Ihnen zusätzliche staatliche Förderboni (iSFP-Bonus).",
    icon: <Map className="w-8 h-8 text-emerald-600" />,
    details: ["Bis zu 5% Extra-Bonus", "Schritt-für-Schritt Planung", "Staatlich gefördert"],
    benefits: [
      "Zusätzlicher 5% Förderbonus auf Einzelmaßnahmen",
      "Erhöhung der förderfähigen Kosten von 30.000€ auf 60.000€ pro Jahr",
      "Klare Priorisierung der Maßnahmen für Ihr Budget",
      "Hoher staatlicher Zuschuss auf die Beratungskosten"
    ],
    documents: [
      "Vollständige Bauunterlagen",
      "Informationen zu bisherigen Sanierungen",
      "Heizkostenabrechnungen der letzten Jahre",
      "Ihre persönlichen Sanierungsziele"
    ],
    pricing: "Eigenanteil meist ca. 800,- € bis 1.500,- € nach staatlicher Förderung.",
    seoTitle: "iSFP Sanierungsfahrplan Düsseldorf | 5% Bonus sichern",
    seoMeta: "Maximal fördern mit dem iSFP Sanierungsfahrplan in Düsseldorf. Markus Lenz optimiert Ihre Energiewende & sichert Zuschüsse. Jetzt beraten lassen!",
    faqs: [
      { 
        question: "Wie hoch ist die Förderung für den iSFP selbst?", 
        answer: "Für die Erstellung eines individuellen Sanierungsfahrplans (iSFP) gibt es eine Förderung von 50 % der Kosten, maximal 650 € bei Ein- oder Zweifamilienhäusern und maximal 850 € bei mehr als zwei Wohneinheiten, gewährt durch das Bundesamt für Wirtschaft und Ausfuhrkontrolle (BAFA)." 
      },
      { question: "Muss ich die Maßnahmen im iSFP umsetzen?", answer: "Nein, der Fahrplan ist eine Empfehlung. Sie entscheiden frei, ob, wann und in welcher Reihenfolge Sie sanieren. Aber: Der 5% Bonus gilt nur für Maßnahmen aus dem iSFP." },
      { question: "Wie lange ist der iSFP gültig?", answer: "Der Sanierungsfahrplan behält seine Gültigkeit für die Bonus-Förderung over einen Zeitraum von 15 Jahren." },
      { question: "Was bringt der iSFP-Bonus genau?", answer: "Er erhöht den Fördersatz für Einzelmaßnahmen (z.B. Fenster, Dämmung) um 5 Prozentpunkte und verdoppelt die maximal förderfähigen Kosten pro Jahr." },
      { question: "Kann ich den iSFP auch für eine WEG erstellen?", answer: "Ja, für Wohnungseigentümergemeinschaften gibt es zudem einen zusätzlichen Zuschuss für die Erläuterung des Fahrplans in einer Eigentümerversammlung." },
      { question: "Wie läuft die Erstellung ab?", answer: "Nach der Datenaufnahme vor Ort erstelle ich das energetische Modell, entwickle Sanierungsvarianten und bespreche das Ergebnis ausführlich mit Ihnen." }
    ]
  },
  {
    id: "heizlast",
    title: "Heizlastberechnung",
    description: "Präzise Berechnung für den optimalen Heizungstausch.",
    longDescription: "Eine raumweise Heizlastberechnung nach DIN 12831 ist die unverzichtbare Basis für jede moderne Heizung, insbesondere für Wärmepumpen. Sie verhindert überdimensionierte und ineffiziente Anlagen.",
    icon: <Thermometer className="w-8 h-8 text-emerald-600" />,
    details: ["Grundlage für WP-Förderung", "Raumweise Berechnung", "Normgerecht nach DIN 12831"],
    benefits: [
      "Optimale Dimensionierung Ihrer neuen Wärmepumpe",
      "Vermeidung von unnötig hohen Stromkosten",
      "Voraussetzung für staatliche Förderprogramme",
      "Besserer Wohnkomfort durch perfekt abgestimmte Raumtemperaturen"
    ],
    documents: [
      "Detaillierte Grundrisse",
      "U-Werte der Bauteile (oder Baujahresbeschreibung)",
      "Fenstermaße und -qualitäten",
      "Informationen zur geplanten Heizungsart"
    ],
    pricing: "Nach Aufwand und Gebäudegröße, meist ab ca. 350,- € inkl. MwSt.",
    seoTitle: "Heizlastberechnung Düsseldorf | Wärmepumpen-Check",
    seoMeta: "Präzise Heizlastberechnung nach DIN 12831 in Düsseldorf. Basis für Förderung & effiziente Wärmepumpen. Markus Lenz berät Sie kompetent vor Ort.",
    faqs: [
      { question: "Warum reicht die alte Kesselleistung nicht aus?", answer: "Alte Kessel sind oft massiv überdimensioniert. Moderne Systeme wie Wärmepumpen müssen exakt passen, um effizient and materialschonend zu laufen." },
      { question: "Ist die Berechnung für die Förderung Pflicht?", answer: "Ja, für fast alle Förderprogramme beim Heizungstausch ist eine raumweise Heizlastberechnung als Nachweis zwingend erforderlich." },
      { question: "Was passiert ohne Heizlastberechnung?", answer: "Die Heizung wird oft 'auf Verdacht' zu groß gewählt. Das führt zu Takten (ständiges Ein/Aus), höherem Verschleiß und unnötig hohen Stromverbräuchen." },
      { question: "Wie lange dauert die Berechnung?", answer: "Sobald alle Gebäudedaten vorliegen, erstelle ich die raumweise Berechnung innerhalb weniger Werktage." },
      { question: "Was kostet die Berechnung für ein EFH?", answer: "In der Regel liegt der Aufwand bei einem Standard-Einfamilienhaus zwischen 350 und 500 Euro." },
      { question: "Kann ich die Daten selbst liefern?", answer: "Ja, gute Grundrisse und Infos zu Fenstern and Dämmung beschleunigen den Prozess erheblich." }
    ]
  },
  {
    id: "abgleich",
    title: "Hydraulischer Abgleich",
    description: "Effizienzsteigerung Ihres bestehenden Heizsystems.",
    longDescription: "Beim hydraulischen Abgleich wird sichergestellt, dass jeder Heizkörper genau die Wärmemenge erhält, die er benötigt. Das spart Energie, schont die Umwälzpumpe und eliminiert störende Fließgeräusche. Wichtig: Der hydraulische Abgleich ist eine zwingende technische Voraussetzung für den Erhalt staatlicher Förderungen (KfW/BAFA) beim Einbau einer neuen Wärmepumpe.",
    icon: <Settings className="w-8 h-8 text-emerald-600" />,
    details: ["Pflicht für WP-Förderung", "Heizkostenersparnis bis 15%", "Staatlich bezuschusst"],
    benefits: [
      "Zwingende Voraussetzung für Wärmepumpen-Förderung",
      "Gleichmäßige Erwärmung aller Räume",
      "Reduzierung der Vorlauftemperatur möglich",
      "Weniger Pumpenstrom und leisere Heizkörper",
      "Staatlich gefördert im Rahmen der Heizungsoptimierung"
    ],
    documents: [
      "Übersicht der Heizkörpergrößen",
      "Vorhandene Ventileinstellmöglichkeiten",
      "Leistungsdaten der Heizungspumpe"
    ],
    pricing: "Individuelles Angebot je nach Anzahl der Heizkörper.",
    seoTitle: "Hydraulischer Abgleich Düsseldorf | Pflicht für WP-Förderung",
    seoMeta: "Hydraulischer Abgleich in Düsseldorf: Pflicht für die Wärmepumpen-Förderung & Weg zum Energiesparen. Markus Lenz optimiert Ihr System. Jetzt Termin sichern!",
    faqs: [
      { question: "Ist der Abgleich Pflicht für die Wärmepumpen-Förderung?", answer: "Ja, absolut. Um staatliche Zuschüsse (z.B. durch die KfW) für eine neue Wärmepumpe zu erhalten, muss ein hydraulischer Abgleich nach Verfahren B zwingend nachgewiesen werden." },
      { question: "Wann ist ein Abgleich sinnvoll?", answer: "Immer dann, wenn Räume unterschiedlich schnell warm werden, Heizkörper pfeifen oder die Heizkosten trotz moderner Heizung hoch sind." },
      { question: "Wie viel Heizkosten spare ich?", answer: "Durchschnittlich lassen sich durch einen korrekt durchgeführten hydraulischen Abgleich bis zu 15% der Heizenergie einsparen." },
      { question: "Ist der Abgleich gesetzlich vorgeschrieben?", answer: "In vielen Fällen ja. Seit 2022 gibt es für größere Wohngebäude (ab 6 oder 10 Wohneinheiten je nach Energieträger) sogar eine Nachrüstpflicht." },
      { question: "Kann ich den Abgleich selbst machen?", answer: "Nein, dafür werden spezielle voreinstellbare Thermostatventile benötigt und die Einstellwerte müssen per Software berechnet werden." },
      { question: "Wird der Abgleich gefördert?", answer: "Ja, im Rahmen der 'Heizungsoptimierung' gibt es attraktive Zuschüsse durch die BAFA, wenn die Anlage älter als zwei Jahre ist." }
    ]
  },
  {
    id: "beg-em",
    title: "BEG Einzelmaßnahmen",
    description: "Beratung und Begleitung für Fenster, Dämmung und mehr.",
    longDescription: "Wir begleiten Sie bei der Umsetzung einzelner energetischer Maßnahmen wie dem Austausch von Fenstern, der Dämmung der Gebäudehülle oder der Optimierung der Anlagentechnik.",
    icon: <Target className="w-8 h-8 text-emerald-600" />,
    details: ["Antragstellung BAFA/KfW", "Technische Projektprüfung", "Qualitätssicherung"],
    benefits: [
      "Sicherstellung der technischen Mindestanforderungen",
      "Komplette Abwicklung der Förderanträge",
      "Prüfung der Handwerkerangebote",
      "Fachbauleitung und Abnahme der Maßnahmen"
    ],
    documents: [
      "Angebote der ausführenden Firmen",
      "Zustimmungserklärung des Eigentümers",
      "Technische Datenblätter der gewählten Materialien"
    ],
    pricing: "Honorar orientiert sich an der Fördersumme bzw. nach Zeitaufwand (bis zu 50% förderfähig).",
    seoTitle: "BEG Förderung Einzelmaßnahmen Düsseldorf | Lenz Beratung",
    seoMeta: "Förderung für Fenster & Dämmung in Düsseldorf sichern. Markus Lenz begleitet Ihre BEG-Einzelmaßnahmen von Antrag bis Auszahlung. Jetzt informieren!",
    faqs: [
      { question: "Was sind Einzelmaßnahmen (BEG EM)?", answer: "Das sind Sanierungsschritte, die nicht das ganze Haus zum Effizienzhaus machen, sondern gezielt Bauteile verbessern (Dach, Wand, Fenster, Türen)." },
      { question: "Wie hoch ist der aktuelle Fördersatz?", answer: "In der Regel erhalten Sie 15% Zuschuss. Mit einem vorliegenden iSFP erhöht sich dieser Satz auf 20%." },
      { question: "Wann muss der Antrag gestellt werden?", answer: "Zwingend VOR Beauftragung der Handwerker. Ein Planungsvertrag mit dem Energieberater darf jedoch bereits bestehen." },
      { question: "Brauche ich für alles einen Energieberater?", answer: "Für Maßnahmen an der Gebäudehülle (Dämmung, Fenster) ist die Einbindung eines Energieeffizienz-Experten für die Förderung zwingend vorgeschrieben." },
      { question: "Wie lange dauert die Auszahlung der Förderung?", answer: "Nach Abschluss der Maßnahme und Einreichung des Verwendungsnachweises dauert es meist 2-4 Monate bis zur Auszahlung durch die BAFA." },
      { question: "Gibt es eine Obergrenze für die Förderung?", answer: "Ohne iSFP liegen die förderfähigen Kosten bei 30.000€ pro Jahr, mit iSFP steigen sie auf 60.000€ pro Wohneinheit und Kalenderjahr." }
    ]
  }
];

export const PROCESS_STEPS: ProcessStep[] = [
  { title: "Erstkontakt", description: "Kurzes Telefonat oder E-Mail zur Klärung Ihres Anliegens." },
  { title: "Vor-Ort-Termin", description: "Begehung Ihres Objekts in Düsseldorf und Datenaufnahme." },
  { title: "Analyse", description: "Energetische Bewertung und Erstellung der Unterlagen." },
  { title: "Beratung", description: "Besprechung der Ergebnisse und Fördermöglichkeiten." },
  { title: "Umsetzung", description: "Unterstützung bei der Beantragung und Begleitung." }
];

export const FAQS: FAQItem[] = [
  {
    question: "Warum brauche ich einen Energieberater?",
    answer: "Ein Energieberater identifiziert Schwachstellen an Ihrem Haus, plant Sanierungen wirtschaftlich und sichert Ihnen den Zugang zu staatlichen Förderungen (bis zu 70%)."
  },
  {
    question: "Was kostet eine Energieberatung in Düsseldorf?",
    answer: "Die Kosten hängen vom Umfang ab. Ein iSFP wird staatlich bezuschusst, sodass Ihr Eigenanteil für die Planung deutlich reduziert wird."
  },
  {
    question: "Wie schnell bekomme ich einen Termin?",
    answer: "In der Regel melden wir uns innerhalb von 24 Stunden zurück. Ein Vor-Ort-Termin findet meist innerhalb von 1-7 Tagen statt."
  },
  {
    question: "Muss ich Fördermittel selbst beantragen?",
    answer: "Nein, als gelisteter Energieeffizienz-Experte übernehmen wir die komplette technische Antragstellung bei der BAFA oder KfW für Sie."
  }
];
